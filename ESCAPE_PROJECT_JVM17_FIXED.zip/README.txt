SHADE STUDIOS — ESCAPE Android project

This project packages the current ESCAPE HTML game in a native Android WebView.
The game and its soundtrack are bundled locally in app/src/main/assets/index.html,
so the installed app can run offline.

BUILD APK WITH GITHUB ACTIONS
1. Create a new GitHub repository named Escape (or another name).
2. Extract all contents of this ZIP and upload them to the repository root.
   Keep the .github/workflows/build-apk.yml file and the app/ folder.
3. Open the repository's Actions tab.
4. Select "Build ESCAPE APK" and press "Run workflow".
5. When the run finishes successfully, open it and download the
   "ESCAPE-Android-APK" artifact.
6. Extract the downloaded artifact ZIP to get app-debug.apk, then install it
   on your Android phone.

The APK is unsigned for Play Store publishing, but suitable for testing and
installing directly on your own Android device.


APP BRANDING
- Android launcher/app name: Escape
- Launcher icon: cropped from the actual top-down escape pod in the supplied gameplay screenshot.
- Play Store listing icon: play-store-icon-512.png

GOOGLE PLAY NOTE
This project now targets Android 16 (API 36), the current target requirement for new
Google Play apps as of 31 August 2026. The current workflow builds a debug APK for
device testing. A Play Store release needs a signed Android App Bundle (.aab), a
release signing key, store listing assets, a privacy policy URL, and completed
Data safety/content declarations in Play Console. Do not upload the debug APK
as a Play Store release.
